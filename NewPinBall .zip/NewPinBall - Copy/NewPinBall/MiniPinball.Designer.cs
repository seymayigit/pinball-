﻿namespace NewPinBall
{
    partial class MiniPinball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MiniPinball));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.WallTop = new System.Windows.Forms.PictureBox();
            this.WallLeft = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.BallYellow = new System.Windows.Forms.PictureBox();
            this.WallBottom = new System.Windows.Forms.PictureBox();
            this.WallRight = new System.Windows.Forms.PictureBox();
            this.ShooterRod = new System.Windows.Forms.PictureBox();
            this.BallOrange = new System.Windows.Forms.PictureBox();
            this.HoleEntry = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Block = new System.Windows.Forms.PictureBox();
            this.timer2_ShooterRod = new System.Windows.Forms.Timer(this.components);
            this.PictureBoxFilpper_A = new System.Windows.Forms.PictureBox();
            this.PictureBoxFilpper_D = new System.Windows.Forms.PictureBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WallTop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WallLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BallYellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WallBottom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WallRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShooterRod)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BallOrange)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HoleEntry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Block)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxFilpper_A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxFilpper_D)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1, 319);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 56);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // WallTop
            // 
            this.WallTop.Image = ((System.Drawing.Image)(resources.GetObject("WallTop.Image")));
            this.WallTop.Location = new System.Drawing.Point(-1, -1);
            this.WallTop.Name = "WallTop";
            this.WallTop.Size = new System.Drawing.Size(371, 60);
            this.WallTop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.WallTop.TabIndex = 3;
            this.WallTop.TabStop = false;
            // 
            // WallLeft
            // 
            this.WallLeft.Image = ((System.Drawing.Image)(resources.GetObject("WallLeft.Image")));
            this.WallLeft.Location = new System.Drawing.Point(-1, -1);
            this.WallLeft.Name = "WallLeft";
            this.WallLeft.Size = new System.Drawing.Size(58, 336);
            this.WallLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.WallLeft.TabIndex = 4;
            this.WallLeft.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(300, 318);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(69, 62);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(50, 56);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(255, 279);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 6;
            this.pictureBox7.TabStop = false;
            // 
            // BallYellow
            // 
            this.BallYellow.Image = ((System.Drawing.Image)(resources.GetObject("BallYellow.Image")));
            this.BallYellow.Location = new System.Drawing.Point(298, 231);
            this.BallYellow.Name = "BallYellow";
            this.BallYellow.Size = new System.Drawing.Size(20, 20);
            this.BallYellow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BallYellow.TabIndex = 7;
            this.BallYellow.TabStop = false;
            // 
            // WallBottom
            // 
            this.WallBottom.Image = ((System.Drawing.Image)(resources.GetObject("WallBottom.Image")));
            this.WallBottom.Location = new System.Drawing.Point(-1, 318);
            this.WallBottom.Name = "WallBottom";
            this.WallBottom.Size = new System.Drawing.Size(371, 62);
            this.WallBottom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.WallBottom.TabIndex = 8;
            this.WallBottom.TabStop = false;
            // 
            // WallRight
            // 
            this.WallRight.Image = ((System.Drawing.Image)(resources.GetObject("WallRight.Image")));
            this.WallRight.Location = new System.Drawing.Point(301, -1);
            this.WallRight.Name = "WallRight";
            this.WallRight.Size = new System.Drawing.Size(69, 381);
            this.WallRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.WallRight.TabIndex = 9;
            this.WallRight.TabStop = false;
            // 
            // ShooterRod
            // 
            this.ShooterRod.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ShooterRod.Image = ((System.Drawing.Image)(resources.GetObject("ShooterRod.Image")));
            this.ShooterRod.Location = new System.Drawing.Point(296, 251);
            this.ShooterRod.Name = "ShooterRod";
            this.ShooterRod.Size = new System.Drawing.Size(25, 94);
            this.ShooterRod.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ShooterRod.TabIndex = 11;
            this.ShooterRod.TabStop = false;
            // 
            // BallOrange
            // 
            this.BallOrange.Image = ((System.Drawing.Image)(resources.GetObject("BallOrange.Image")));
            this.BallOrange.Location = new System.Drawing.Point(138, 65);
            this.BallOrange.Name = "BallOrange";
            this.BallOrange.Size = new System.Drawing.Size(30, 30);
            this.BallOrange.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BallOrange.TabIndex = 12;
            this.BallOrange.TabStop = false;
            // 
            // HoleEntry
            // 
            this.HoleEntry.Image = ((System.Drawing.Image)(resources.GetObject("HoleEntry.Image")));
            this.HoleEntry.Location = new System.Drawing.Point(63, 104);
            this.HoleEntry.Name = "HoleEntry";
            this.HoleEntry.Size = new System.Drawing.Size(50, 50);
            this.HoleEntry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.HoleEntry.TabIndex = 13;
            this.HoleEntry.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Block
            // 
            this.Block.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Block.Location = new System.Drawing.Point(280, 193);
            this.Block.Name = "Block";
            this.Block.Size = new System.Drawing.Size(10, 152);
            this.Block.TabIndex = 14;
            this.Block.TabStop = false;
            // 
            // timer2_ShooterRod
            // 
            this.timer2_ShooterRod.Interval = 350;
            this.timer2_ShooterRod.Tick += new System.EventHandler(this.timer2_ShooterRod_Tick);
            // 
            // PictureBoxFilpper_A
            // 
            this.PictureBoxFilpper_A.Location = new System.Drawing.Point(50, 262);
            this.PictureBoxFilpper_A.Name = "PictureBoxFilpper_A";
            this.PictureBoxFilpper_A.Size = new System.Drawing.Size(90, 36);
            this.PictureBoxFilpper_A.TabIndex = 15;
            this.PictureBoxFilpper_A.TabStop = false;
            // 
            // PictureBoxFilpper_D
            // 
            this.PictureBoxFilpper_D.Location = new System.Drawing.Point(173, 262);
            this.PictureBoxFilpper_D.Name = "PictureBoxFilpper_D";
            this.PictureBoxFilpper_D.Size = new System.Drawing.Size(90, 36);
            this.PictureBoxFilpper_D.TabIndex = 16;
            this.PictureBoxFilpper_D.TabStop = false;
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // MiniPinball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 378);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.WallLeft);
            this.Controls.Add(this.PictureBoxFilpper_D);
            this.Controls.Add(this.PictureBoxFilpper_A);
            this.Controls.Add(this.Block);
            this.Controls.Add(this.HoleEntry);
            this.Controls.Add(this.BallOrange);
            this.Controls.Add(this.WallTop);
            this.Controls.Add(this.BallYellow);
            this.Controls.Add(this.ShooterRod);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.WallRight);
            this.Controls.Add(this.WallBottom);
            this.Controls.Add(this.pictureBox7);
            this.Name = "MiniPinball";
            this.Text = "MiniPinball";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MiniPinball_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.MiniPinball_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WallTop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WallLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BallYellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WallBottom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WallRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShooterRod)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BallOrange)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HoleEntry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Block)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxFilpper_A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBoxFilpper_D)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox WallTop;
        private System.Windows.Forms.PictureBox WallLeft;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox BallYellow;
        private System.Windows.Forms.PictureBox WallBottom;
        private System.Windows.Forms.PictureBox WallRight;
        private System.Windows.Forms.PictureBox ShooterRod;
        private System.Windows.Forms.PictureBox BallOrange;
        private System.Windows.Forms.PictureBox HoleEntry;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox Block;
        private System.Windows.Forms.Timer timer2_ShooterRod;
        private System.Windows.Forms.PictureBox PictureBoxFilpper_A;
        private System.Windows.Forms.PictureBox PictureBoxFilpper_D;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
    }
}

