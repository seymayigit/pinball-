﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace PinBall2
{
    class Flippers : IDrawable, IMovable
    {

        public double x;
        public double y;
        public double z;
        public double t;


        public Flippers(double x, double y, double alpha)
        {

            this.x = x;
            this.y = y;
            move1(alpha);

        }

        public void draw(Graphics grp)
        {
            grp.DrawLine(Pens.Orange, (int)x, (int)y, (int)z, (int)t);
           
        }
        public void move()
        {

        }
        public void move1(double angle)
        {
            z = x + 50.0 *Math.Cos(angle*Math.PI/180);
            t = y + 50.0 *Math.Sin(angle * Math.PI / 180);
        }


        public bool isCollideWithFlipperAndBall(Ball ball, ref float lineX,
        ref float lineY)
        {
            double ballCenterX = ball.location.x + ball.radius;
            double ballCenterY = ball.location.y + ball.radius;
            float artis;
            if (Math.Abs(this.x - this.z) > Math.Abs(this.y - this.t))
            {
                artis = (float)(1.0 / Math.Abs(this.x - this.z));

            }
            else
            {
                artis = (float)(1.0 / Math.Abs(this.y - this.t));
            }

            for (float i = 0; i <= 1; i += artis)
            {
                lineX = (float)(this.x + (int)((this.z - this.x) * i));
                lineY = (float)(this.y + (int)((this.t - this.y) * i));

                if (Math.Sqrt(Math.Pow((ballCenterX - lineX), 2) + Math.Pow((ballCenterY - lineY), 2)) <= ball.radius)
                {
                 //   MessageBox.Show(ballCenterX + " " +" "+ballCenterY+" "+ lineX + " " + lineY);
                  

                    return true;
                }
            }
            return false;
        }



    }
}
