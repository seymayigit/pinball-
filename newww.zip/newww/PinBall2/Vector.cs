﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PinBall2
{
    class Vector
    {
        public double x;
        public double y;
       
        public Vector()
        {

        }
        public Vector(double x, double y)
        {
            this.x = x;
            this.y = y;
        }
        public Vector normalize()
        {
            double length = Math.Sqrt((x * x + y * y));
            return new Vector(x / length, y / length);

        }
        public double length()
        {
            return Math.Sqrt((x * x + y * y));
        }
        public static Vector operator +(Vector v1, Vector v2)
        {
            return new Vector(v1.x + v2.x, v1.y + v2.y);
        }
        public static Vector operator -(Vector v1, Vector v2)
        {
            return new Vector(v1.x - v2.x, v1.y - v2.y);
        }
        public static Vector operator *(Vector v1, float number)
        {
            return new Vector(v1.x * number, v1.y * number);
        }
        public static Vector operator /(Vector v1, float number)
        {
            return new Vector(v1.x / number, v1.y / number);
        }
    }
}
