﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PinBall2
{
    class Blocks : IDrawable
    {
        public int x; 
        public int y;
        public int z;
        public int t;


        public Blocks(int x, int width, int height)
        {
            this.x = x;
            this.y = y=0;
            this.z =width;
            this.t = height;

        }


        public void draw(Graphics grp)
        {
            grp.FillRectangle(Brushes.RoyalBlue, x, y, z, t);

        }
        public bool isCollideWithBlockAndBall(Ball ball, ref float lineX, ref float lineY)
        {
            double ballCenterX = ball.location.x + ball.radius;
            double ballCenterY = ball.location.y + ball.radius;
            float artis;
            if (Math.Abs(this.x - (this.z+this.x)) > Math.Abs(this.t - this.t))
            {
                artis = (float)(1.0 / Math.Abs(this.x - (this.z+this.x)));

            }
            else
            {
                artis = (float)(1.0 / Math.Abs(this.t - this.t));
            }

            for (float i = 0; i <= 1; i += artis)
            {
                lineX = (float)(this.x + (int)(((this.z + this.x) - this.x) * i));
                lineY = (float)(this.t + (int)((this.t - this.t) * i));

                if (Math.Sqrt(Math.Pow((ballCenterX - lineX), 2) + Math.Pow((ballCenterY - lineY), 2)) <= ball.radius)
                {
                    return true;
                }
            }
            return false;
        }

    }
}
