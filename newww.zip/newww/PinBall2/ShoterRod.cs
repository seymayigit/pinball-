﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace PinBall2
{
    class ShoterRod :IDrawable 
    {
        
        public int x;
        public int y;
        public int width;
        public int height;

        public ShoterRod(int a,int b)
        {
            x = a - 20;
            y = b - 90;
            width = a - x;
            height = b - y;
        }
        public void draw(Graphics grp)
        {
            grp.FillRectangle(Brushes.Blue, x, y, width, height);
        }
       

       
    }
}
