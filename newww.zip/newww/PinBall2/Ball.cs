﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PinBall2
{
    class Ball : IDrawable, IMovable
    {



        public int radius;
        public Brush brush;
        public int directionX;  
        public int directionY;
        public Vector location;
        const int ground = 373;
        public Ball(int x, int y, int radius, Brush color)
        {
            
            this.radius = radius;
            this.brush = color;
           
            directionX = 0;
            directionY = -2;
            location = new Vector((double)x, (double)y);
        }
        public void draw(Graphics grp)
        {
            Rectangle r = new Rectangle((int)location.x, (int)location.y, radius * 2, radius * 2);
           //  grp.FillEllipse(brush, (int)location.x, (int)location.y, radius * 2, radius * 2);
            grp.FillEllipse(brush, r);
          
        }


        public void move()
        {
            location.x += directionX;
            location.y += directionY;
      
        }
        public bool isCollideWithFlippers(Vector p1, Vector p2)
        {
            Vector center = new Vector(location.x + radius, location.y + radius);
            Vector v1 = p2 - p1;
            Vector v2 = center - p1;
            double alpha = Math.Acos(Math2D.dotProduct(v1, v2));///açı radyan olacak..

            double v2Length = v2.length();
            double distance = v2Length * Math.Sin(alpha);

            if (distance <= radius)
            {

                return true;

            }
                

            return false;

        }

        public bool isCollideWithBall(Ball ball1)
        {

            Vector center = new Vector(location.x + radius, location.y + radius);
            Vector center1 = new Vector(ball1.location.x + ball1.radius, ball1.location.y + ball1.radius);
            Vector v1 = center - center1;

            if (v1.length() <= radius + ball1.radius)
            {
                return true;

            }
                

            return false;

        }
        public void reflection(string direct)
        {
            if (direct == "yandan")
            {
                directionX = -directionX;
            }
            if (direct == "dikey")
            {
                directionY = -directionY;
            }
            if(direct=="cekim")
            {
               
                directionX = directionX < 0 ? directionX - 4 : directionX + 4;
                directionY = 0;
            }

           
          

        }
       
        
        public void play(ref double xspeed, ref double yspeed, ref double newyspeed, ref double startingypos, ref double newxpos, ref double newypos, ref double oldxpos, ref double oldypos, ref double newx, ref double oldx, ref double newy, ref double oldy, ref double acc, ref double t, ref int xmouse, ref int ymouse, ref bool dragging, ref bool trace, ref bool collisiony)
        {
            

            location.x = (int)newxpos;
            location.y = (int)newypos;

            // This code will be visited 50 times per second while dragging
            if (dragging)
            {
                acc = (double)10;
                location.x = xmouse;
                location.y= ymouse;

                startingypos = ground - location.y;

                newx = location.x;
                newy = ground - location.y;
                xspeed = (newx - oldx) / 1;
                yspeed = (newy - oldy) / 1;
                oldx = newx;
                oldy = newy;

                t = 0;

            }
            else
            {
                acc = (double)10;
                oldxpos = location.x;
                // X-axis motion
                if (location.x < 357 && 0 < location.x)
                {
                    newxpos = oldxpos + xspeed;
                }
                else
                {
                    xspeed *= -0.9;	// Wall resistance	
                    newxpos = oldxpos + xspeed;
                }

                // Y-axis motion
                if (0 < newypos || collisiony)
                {
                    newyspeed = yspeed - (acc * t);
                    newypos = startingypos + ((yspeed * t) - 0.5 * acc * (t * t));
                    collisiony = false;
                }
                else
                {  // Here the ball will hits the ground
                    // Initialize the ball variables again
                    startingypos = -1;
                    // Here set startingypos=-1 not 0, because if 0 newypos will be 0 every time the ball 
                    // Hits the ground so no bouncing will happens to the ball, evaluate to the 
                    // eguation below for newypos when t = 0
                    t = 0;
                    // Ball yspeed will decrease every time it hits the ground
                    // 0.75 is the elasticity coefficient - assumption
                    // The initial speed(yspeed) is 0.75 of the final speed(newyspeed)
                    yspeed = newyspeed * -0.75;
                    newypos = startingypos + ((yspeed * t) - 0.5 * acc * (t * t));
                    collisiony = true;
                }
                // Always
                // Ball xspeed will always decrease, even if it didn't hit the wall
                xspeed *= 0.99;	// Air resistance

                if (xspeed > -0.5 && xspeed < 0)
                    xspeed = 0;

                #region Explination of xspeed condition above
                // This condition is to stop the ball when it heading to the left, you can notice that removeing
                // this condition will make the ball never stop while its heading to the left until it will
                // hit the left wall, to know why, run the simulation under the debuging mode and watch
                // the value of newxpos
                // newxpos = oldxpos + xspeed
                // when 0 < xspeed < 1 (the ball heading right), ball.left = (int)newxpos, the casting 
                // forces the ball left position value to be the same as its previous value, because oldxpos and newxpos are equals, and hence the ball will stop.
                // but when -1 < xspeed < 0 (the ball heading left), ball.left = (int)newxpos, the casting
                // here will not work correctly, because the value of oldxpos(which is integer value see line 185) will always 
                // be decremented by the xspeed, this will force the newxpos also to be always decremented by xspeed and hence
                // ball.left will always decremented by 1 (int) casting, and hence the ball will never stop.
                #endregion

                // Update the ball position
                location.x = (int)newxpos;
                location.y = (int)(ground - newypos);
                // Increase the time
                t += 0.3;
            }
        }


        
    }
    }
