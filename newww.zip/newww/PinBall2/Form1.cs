﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PinBall2
{
    public partial class PinBall : Form
    {
        double xspeed, yspeed, newyspeed, startingypos;
        double newxpos, newypos, oldxpos, oldypos;
        double newx, oldx, newy, oldy;
        double acc, t;
        const int ground = 373;
        int xmouse, ymouse;
        bool dragging = true, trace, collisiony;
        private System.Timers.Timer timer;
		
        ShoterRod shoterRod;

        Flippers flipper_1;
        Flippers flipper_2;
        Flippers flipperCorner;
        double flipperCornerAlpha = 30.0;

        Ball ball;
        Ball ball_1;

        private int i;
        private int pressKeyA_angle = 20;
        private int pressKeyD_angle = 160;
        private bool pressKeyA_flag = false;
        private bool pressKeyD_flag = false;
        private bool flag = true;
        private bool flag_WhiteWallCollision = true;

        float lineX = 0;
        float lineY = 0;
        // double çizdirilecekAçı = 0.0;
        bool moveOrMove1_flag = true;
        //    bool flag_ = false;
        Bitmap btm;
        
        public PinBall()
        {
            SetStyle(ControlStyles.DoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);//how can i make pinball flippers work correctly?
            InitializeComponent();
            shoterRod = new ShoterRod(this.ClientSize.Width - 15, this.ClientSize.Height - 20);
            ball = new Ball(shoterRod.x, shoterRod.y - 20, 10, Brushes.Red);


            ball_1 = new Ball(100, 100, 10, Brushes.Yellow);

            flipper_1 = new Flippers(100, this.ClientSize.Height - 67, 20.0);
            flipper_2 = new Flippers(215, this.ClientSize.Height - 63, 160.0);

            flipperCorner = new Flippers(this.ClientSize.Width - 30, 0, flipperCornerAlpha);

            newxpos = ball.location.x;
            newypos = ball.location.y;

            xmouse = (int)(ball.location.x + ball.directionX);
            ymouse = (int)(ball.location.y + ball.directionY);

        }


        void PinBall_Paint(object sender, PaintEventArgs e)
        {


            ball.draw(e.Graphics);
            ball_1.draw(e.Graphics);

            flipper_1.draw(e.Graphics);
            flipper_2.draw(e.Graphics);
            flipperCorner.draw(e.Graphics);

            shoterRod.draw(e.Graphics);

        }


        private void timer1_Tick(object sender, EventArgs e)
        {

            //if (ball.isCollideWithFlippers(new Vector(0.0, 0.0), new Vector(this.ClientSize.Width, 0.0)))
            //{
            //    ball.reflection("dikey");


            //}
                //if (ball.isCollideWithFlippers(new Vector(0.0, this.ClientSize.Height), new Vector(this.ClientSize.Width, this.ClientSize.Height)))
                //{
                //    ball.reflection("dikey");

                //}
                //if (ball.isCollideWithFlippers(new Vector(0.0, 0.0), new Vector(0.0, this.ClientSize.Height)))
                //{
                //    ball.reflection("yandan");


                //}
                //if (ball.isCollideWithFlippers(new Vector(this.ClientSize.Width, 0.0), new Vector(this.ClientSize.Width, this.ClientSize.Height)))
                //{
                //    ball.reflection("yandan");

                //}

                //if (flipperCorner.isCollideWithFlipperAndBall(ball, ref lineX, ref lineY))
                //{

                //    ball.directionX = 2;
                //    ball.directionY = 2;
                //    ball.directionX = -ball.directionX;
                //    ball.directionY = +ball.directionY;
                //}
                //if (flipper_1.isCollideWithFlipperAndBall(ball, ref lineX, ref lineY))
                //{


                //}

                //if (flipper_2.isCollideWithFlipperAndBall(ball, ref lineX, ref lineY))
                //{
                //    ball.directionX = 2;
                //    ball.directionY = 2;
                //    ball.directionX = -ball.directionX;
                //    ball.directionY = +ball.directionY;
                //}

                //if (ball.isCollideWithBall(ball_1))
                //{
                //    ball.directionX = 2;
                //    ball.directionY = 2;
                //    ball.directionX = +ball.directionX;
                //    ball.directionY = +ball.directionY;
                //}

               




             //   ball.move();


             //   Color color = btm.GetPixel((int)(ball.location.x + 2 * ball.radius), (int)(ball.location.y));
              //  Color color = btm.GetPixel(309, 63);

                //if (color.R == 255 && color.G == 255 && color.B == 255 )
                //{
                //    ball.directionX = -2;
                //    ball.directionY = -1;
                //    //y azalsın x artsın ..

                   



                //}


            newxpos = ball.location.x;
            newypos = ball.location.y;

            xmouse = (int) (ball.location.x + ball.directionX);
            ymouse = (int)(ball.location.y + ball.directionY);


                Invalidate();


                //dragging = !dragging;



        }


        private void PinBall_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.A)
            {
                pressKeyA_flag = true;
                pressKeyD_flag = false;

                timer2.Start();
                timer3.Stop();

            }

            if (e.KeyCode == Keys.D)
            {
                pressKeyD_flag = true;

                pressKeyA_flag = false;
                timer2.Start();
                timer3.Stop();

            }

            if (e.KeyCode == Keys.S)
            {

                if (flag)
                {
                    timer4.Start();
                    Invalidate();

                }
                if (!flag)
                {
                    timer4.Enabled = false;
                }

            }


        }
        private void PinBall_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                pressKeyA_flag = true;
                pressKeyD_flag = false;
                timer2.Stop();
                timer3.Start();

            }
            if (e.KeyCode == Keys.D)
            {
                pressKeyD_flag = true;
                pressKeyA_flag = false;
                timer2.Stop();
                timer3.Start();

            }

            if (e.KeyCode == Keys.S)
            {
                timer4.Stop();
                flag = false;

                if (i >= 0 && i <= 3)
                {
                    timer1.Interval = 30;
                }
                if (i > 3 && i <= 6)
                {
                    timer1.Interval = 15;
                }
                if (i > 6 && i <= 100)
                {
                    timer1.Interval = 2;
                }
                timer1.Enabled = true;
               
            }


        }


        private void timer4_Tick(object sender, EventArgs e)
        {

            i++;
            if (shoterRod.y != this.ClientSize.Height - 30)
            {
                ball.location.y += 10;
                shoterRod.y += 10;
                shoterRod.height -= 10;
            }

        }

        private void timer2_Tick(object sender, EventArgs e)
        {


            if (pressKeyA_angle >= -20 && pressKeyA_flag == true && pressKeyD_flag != true)
            {
                flipper_1.move1((double)pressKeyA_angle);
                pressKeyA_angle -= 10;
                Invalidate();


            }
            if (pressKeyD_angle <= 200 && pressKeyD_flag == true && pressKeyA_flag != true)
            {
                flipper_2.move1((double)pressKeyD_angle);
                pressKeyD_angle += 10;
                Invalidate();


            }



        }
        private void timer3_Tick(object sender, EventArgs e)
        {
            if (pressKeyA_angle <= 20 && pressKeyA_flag == true && pressKeyD_flag != true)
            {
                flipper_1.move1((double)pressKeyA_angle);
                pressKeyA_angle += 10;
                Invalidate();


            }
            if (pressKeyD_angle >= 160 && pressKeyD_flag == true && pressKeyA_flag != true)
            {
                flipper_2.move1((double)pressKeyD_angle);
                pressKeyD_angle -= 10;
                Invalidate();


            }


        }

        private void PinBall_MouseMove_1(object sender, MouseEventArgs e)
        {
            //xmouse = e.X;
            //ymouse = e.Y;

            //xmouse = 150;
            //ymouse = 150;
            
            label2.Text = PointToClient(Cursor.Position).ToString();

        }

        private void PinBall_Load(object sender, EventArgs e)
        {

            btm = new Bitmap(BackgroundImage);
        }

        private void PinBall_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void PinBall_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            //newxpos = e.X;
            //newypos = e.Y;

            //newxpos = 300;
            //newypos = 100;
                   
        }

       

       
    }
}
